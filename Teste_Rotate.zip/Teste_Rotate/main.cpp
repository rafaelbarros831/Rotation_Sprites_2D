#include <stdio.h>
#include <SFML/Graphics.hpp>

int main() {
	printf("Bla bla");

	/*sf::RectangleShape quadrado(sf::Vector2f(100.0f, 100.0f));
	quadrado.setFillColor(sf::Color::Green);
	quadrado.setPosition(sf::Vector2f(300.0f, 300.0f));*/

	sf::Texture tx_mario("x64/Debug/Mario.png");
	sf::Sprite Mario(tx_mario);
	Mario.setPosition(sf::Vector2f(300.0f, 300.0f));
	Mario.setScale(sf::Vector2f(0.2f, 0.2f));

	sf::FloatRect Center = Mario.getLocalBounds();
	Mario.setOrigin(sf::Vector2f(Center.size.x / 2.0f, Center.size.y / 2.0f));
	sf::RenderWindow janela(sf::VideoMode({600, 600}), "Janela");
	
	while (janela.isOpen() == true) {

		while (std::optional evento = janela.pollEvent()) {

			if (evento->is<sf::Event::Closed>()) {
				janela.close();
			}

		}


		janela.clear(sf::Color::Cyan);


		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::A)) {
			Mario.setRotation(sf::degrees(-90.0f));
		}

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::S)) {
			Mario.setRotation(sf::degrees(-180.0f));
		}

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::D)) {
			Mario.setRotation(sf::degrees(-270.0f));
		}

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::F)) {
			Mario.setRotation(sf::degrees(-360.0f));
		}

		sf::Vector2f CalPosi = Mario.getTransform().transformPoint(sf::Vector2f(0.0f, 0.0f));

		printf("X = %.2f, Y = %.2f, Angulo: %f graus\n", CalPosi.x, CalPosi.y, Mario.getRotation().asDegrees());

		janela.draw(Mario);
		janela.display();
	}

return 0;
}